import React from 'react';
import {View, Text, Image, ScrollView, TextInput} from 'react-native';

const App = () => {
  return (
    <ScrollView>
      <Text style={{backgroundColor: 'red'}}>Some text</Text>
      <View>
        <Text style={{backgroundColor: 'yellow'}}>Some more text</Text>
        <Image 
          source={{
            uri: 'https://img.freepik.com/free-photo/a-cupcake-with-a-strawberry-on-top-and-a-strawberry-on-the-top_1340-35087.jpg?w=360',
          }}
          style={{width: 100, height: 100, alignItems:'right'}}
        />
      </View>
      <TextInput
        style={{
          height: 40,
          borderColor: 'white',
          borderWidth: 1,
          backgroundColor:'green',
          marginLeft:10,
          textAlign:'center',
          
          
        }}
        defaultValue="You can type in me"
      />
    </ScrollView>
  );
};

export default App;